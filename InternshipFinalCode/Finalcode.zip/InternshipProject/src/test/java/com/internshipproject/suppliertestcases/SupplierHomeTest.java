package com.internshipproject.suppliertestcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.internshipproject.constants.AutomationConstants;
import com.internshipproject.supplierpages.SupplierHomePage;
import com.internshipproject.supplierpages.SupplierLoginPage;
import com.internshipproject.utilities.ExcelUtility;

public class SupplierHomeTest extends SupplierLoginTest {
	SupplierLoginTest objLogin;
	SupplierHomeTest objHome;
	
	//MY BOOKINGS VALIDATION
		@Test(priority=1)
	    public void verifyMyBookings() throws IOException, InterruptedException {
		SupplierLoginPage objLogin = new SupplierLoginPage(driver);
		SupplierHomePage objHome=new SupplierHomePage(driver);
		//login to application
	   // String username = ExcelUtility.getCellData(0, 2);
	   // String password = ExcelUtility.getCellData(0, 3);
		String username = "supplier@phptravels.com";
	    String password = "demosupplier";
	    objLogin.setUserName(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();
	    Thread.sleep(5000);
	    objHome.clickBookings();
	    
	    String expectedUrl ="https://phptravels.net/api/supplier/bookings";
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully: BUT PAGE IS EMPTY");
	   
		}
	

		//TOURS VALIDATION
			@Test(priority=1)
		    public void verifyTours() throws IOException  , InterruptedException {
		    //Create Login Page object
			SupplierLoginPage objLogin = new SupplierLoginPage(driver);
			SupplierHomePage objHome=new SupplierHomePage(driver);
			//login to application
		    String username = "supplier@phptravels.com";
		    String password = "demosupplier";
		    objLogin.setUserName(username);
		    objLogin.setPassword(password);
		    objLogin.clickLogin();
		    Thread.sleep(5000);
		    objHome.clickTours();
		    String expectedUrl =AutomationConstants.SUPPLIERTOURSURL;
		    String actualUrl =driver.getCurrentUrl();
		    Assert.assertNotEquals(expectedUrl,actualUrl);
		    System.out.println("Test Passed successfully: Tours Link not working");
		   
			}
			
		//Revenue breakdown validation
			
		
			@Test(priority=1)
		    public void verifyRevenue() throws IOException {
		    //Create Login Page object
			SupplierLoginPage objLogin = new SupplierLoginPage(driver);
			SupplierHomePage objHome=new SupplierHomePage(driver);
			//login to application
		    String username = "supplier@phptravels.com";
		    String password = "demosupplier";
		    objLogin.setUserName(username);
		    objLogin.setPassword(password);
		    objLogin.clickLogin();
		    String expectedText=AutomationConstants.SUPPLIERREVENUE;
		    //objHome.clickRevenue();
		    
		   
		    
		    
		    Assert.assertEquals(expectedText,"Revenue Breakdown 2022");
		    System.out.println("Test Passed successfully");
		    
		    
			}
		
			
			//SalesOverview Validation
			
			@Test(priority=1)
		    public void verifySales() throws IOException {
		    //Create Login Page object
			SupplierLoginPage objLogin = new SupplierLoginPage(driver);
			SupplierHomePage objHome=new SupplierHomePage(driver);
			//login to application
		    String username = "supplier@phptravels.com";
		    String password = "demosupplier";
		    objLogin.setUserName(username);
		    objLogin.setPassword(password);
		    objLogin.clickLogin();
		    String expectedText=AutomationConstants.SUPPLIERSALES;
		    //objHome.clickSales();
		    
		    Assert.assertEquals(expectedText,"Sales overview & summary");
		    System.out.println("Test Passed successfully");
		    
		    
			}
		
			
			
		
}
