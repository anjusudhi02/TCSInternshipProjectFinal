package com.internshipproject.suppliertestcases;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class SupplierBaseClass {
	
	WebDriver driver;
	//WebDriver driver2;
	public static Properties prop=null;
	String driverPath="F:\\mavenworkspace\\mavenproject\\drivers\\chromedriver.exe";
	
	public static void TestBaseClass() {
	try {
		prop=new Properties();
	    FileInputStream ip=new FileInputStream(System.getProperty("user.dir")+"/src/test/resources"+"/config.properties");
		prop.load(ip);	
		}
	catch (FileNotFoundException e)
	{
		e.printStackTrace();
		
	}
	catch (IOException e) {
		e.printStackTrace();
	}
	
	}
@BeforeMethod
public void onSetup() {
	TestBaseClass();
	String browsername=prop.getProperty("browser");
	if(browsername.equals("chrome"))
	{System.setProperty("webdriver.chrome.driver",driverPath);
	driver=new ChromeDriver();
	}
	else if(browsername.equals("firefox")) {
		System.setProperty("Webdriver.gecko.driver",driverPath);
		driver=new FirefoxDriver();
		
	}
	
	//driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	driver.get(prop.getProperty("suppurl"));
	driver.manage().window().maximize();
	
	}

@AfterMethod

public void TearDown()
{
	
driver.quit();

}

}
