package com.internshipproject.customertestcases;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.internshipproject.Agentpages.AgentHomePage;
import com.internshipproject.Agentpages.AgentLoginPage;
import com.internshipproject.constants.AutomationConstants;
import com.internshipproject.customerpages.CustomerHomePage;
import com.internshipproject.customerpages.CustomerLoginPage;
import com.internshipproject.utilities.ExcelUtility;

public class CustomerHomeTest extends CustomerLoginTest {
	
	CustomerHomePage  objcustomer;
	
	// VERIFY MYBOOKINGS
	@Test(priority = 0)
	public void verifyMyBookings() throws IOException {
	
		//CustomerHomePage objcustomer = new CustomerHomePage(driver);
		//obj_customer.languageSelect();
		//obj_customer.selectLoginPage();
		objLogin = new CustomerLoginPage(driver);
		objcustomer= new CustomerHomePage(driver);
		//objLogin = new AgentLoginPage(driver)
		
		String username = ExcelUtility.getCellData(0, 4);
	    String password = ExcelUtility.getCellData(0, 5);
	    objLogin.setUsername(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();	
	    
	    objcustomer.clickMybooking();
		
		
		String expectedBookingURL = AutomationConstants.CUSTOMERMYBOOKINGSURL;
		String actualBookingURL = driver.getCurrentUrl();
		Assert.assertEquals(expectedBookingURL, actualBookingURL);
		System.out.println("Test Passed successfully");
		
	}
	
	
	
	@Test(priority =1 )
	public void verifyMyProfile() throws IOException {
	
		//CustomerHomePage objcustomer = new CustomerHomePage(driver);
		//obj_customer.languageSelect();
		//obj_customer.selectLoginPage();
		objLogin = new CustomerLoginPage(driver);
		objcustomer= new CustomerHomePage(driver);
		//objLogin = new AgentLoginPage(driver)
		
		String username = ExcelUtility.getCellData(0, 4);
	    String password = ExcelUtility.getCellData(0, 5);
	    objLogin.setUsername(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();	
	    
	    
	    objcustomer.clickMyProfile();
		String expectedURL = AutomationConstants.CUSTOMERMYPROFILEURL;
		String actualURL = driver.getCurrentUrl();
		Assert.assertEquals(expectedURL, actualURL);
		System.out.println("Test Passed successfully");
		
	}
	
	@Test(priority =2 )
	public void verifyAddFunds() throws IOException{
	
		//CustomerHomePage objcustomer = new CustomerHomePage(driver);
		//obj_customer.languageSelect();
		//obj_customer.selectLoginPage();
		objLogin = new CustomerLoginPage(driver);
		objcustomer= new CustomerHomePage(driver);
		//objLogin = new AgentLoginPage(driver)
		
		String username = ExcelUtility.getCellData(0, 4);
	    String password = ExcelUtility.getCellData(0, 5);
	    objLogin.setUsername(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();	
	    
	    objcustomer.clickAddFunds();
		String expectedURL = AutomationConstants.CUSTOMERADDFUNDSURL;
		String actualURL = driver.getCurrentUrl();
		Assert.assertEquals(expectedURL, actualURL);
		System.out.println("Test Passed successfully");
	
}
	//VERIFY LOGOUT
	@Test(priority =3 )
	public void verifyLogout() throws IOException{
	
		//CustomerHomePage objcustomer = new CustomerHomePage(driver);
		//obj_customer.languageSelect();
		//obj_customer.selectLoginPage();
		objLogin = new CustomerLoginPage(driver);
		objcustomer= new CustomerHomePage(driver);
		//objLogin = new AgentLoginPage(driver)
		
		String username = ExcelUtility.getCellData(0, 4);
	    String password = ExcelUtility.getCellData(0, 5);
	    objLogin.setUsername(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();	
	    	
	    
	    objcustomer.clickLogout();
		String expectedURL = AutomationConstants.CUSTOMERLOGOUT;
		String actualURL = driver.getCurrentUrl();
		Assert.assertEquals(expectedURL, actualURL);
		System.out.println("Test Passed successfully");
	
}
	//VERIFY PAYPAL PAYMENT
	
	@Test(priority =4 )
	public void verifyPayment() throws IOException {
	
			
	//CustomerHomePage objcustomer = new CustomerHomePage(driver);
		//obj_customer.languageSelect();
		//obj_customer.selectLoginPage();
		objLogin = new CustomerLoginPage(driver);
		objcustomer= new CustomerHomePage(driver);
		//objLogin = new AgentLoginPage(driver)
		
		String username = ExcelUtility.getCellData(0, 4);
	    String password = ExcelUtility.getCellData(0, 5);
	    objLogin.setUsername(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();	
	    
	    
		objcustomer.clickAddFunds();
		
		/*
		if(obj_alert.isDialogPresent(driver)) {
			obj_alert.acceptBrowserAlert(driver);
		}
		Thread.sleep(3000);*/
		
		
		objcustomer.paypal();
		//Thread.sleep(3000);
		String expectedPaypalURL = AutomationConstants.CUSTOMERPAYPALURL;
		String actualPaypalURL = driver.getCurrentUrl();
		Assert.assertEquals(expectedPaypalURL, actualPaypalURL);
		System.out.println("Test Passed successfully");
	
	}
	
	//VERIFY VOUCHER
	@Test(priority =5 )
	public void verifyVoucher() throws IOException {
		//CustomerHomePage objcustomer = new CustomerHomePage(driver);
		//obj_customer.languageSelect();
		//obj_customer.selectLoginPage();
		objLogin = new CustomerLoginPage(driver);
		objcustomer= new CustomerHomePage(driver);
		//objLogin = new AgentLoginPage(driver)
		
		String username = ExcelUtility.getCellData(0, 4);
	    String password = ExcelUtility.getCellData(0, 5);
	    objLogin.setUsername(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();	
	    	
	    objcustomer.clickMybooking();
	    objcustomer.viewVoucher();
	    
	  //  Thread.sleep(3000);
		String expectedVoucherURL = AutomationConstants.CUSTOMERVOUCHERURL;
		String actualVoucherURL = driver.getCurrentUrl();
		Assert.assertEquals(expectedVoucherURL, actualVoucherURL);
		System.out.println("Test Passed successfully");
	
}
	
	@Test(priority =6 )
	public void verifyUpdateAddress() throws IOException{
	
		//CustomerHomePage objcustomer = new CustomerHomePage(driver);
		//obj_customer.languageSelect();
		//obj_customer.selectLoginPage();
		objLogin = new CustomerLoginPage(driver);
		objcustomer= new CustomerHomePage(driver);
		//objLogin = new AgentLoginPage(driver)
		
		String username = ExcelUtility.getCellData(0, 4);
	    String password = ExcelUtility.getCellData(0, 5);
	    objLogin.setUsername(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();	
	    
	    
	    objcustomer.clickMyProfile();
	    
		JavascriptExecutor js = (JavascriptExecutor)driver; 
		js.executeScript("window.scroll(0,1000)");
		String address1 = "kerala 665432";
		String address2 = "India";
		objcustomer.updateAddress1(address1);
		objcustomer.updateAddress2(address2);
		objcustomer.clickUpdateProfile();
	
	}
	
}
