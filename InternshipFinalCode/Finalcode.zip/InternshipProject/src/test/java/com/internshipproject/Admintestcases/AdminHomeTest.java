package com.internshipproject.Admintestcases;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.internshipproject.adminpages.AdminHomePage;
import com.internshipproject.adminpages.AdminLoginPage;
import com.internshipproject.constants.AutomationConstants;
import com.internshipproject.utilities.ExcelUtility;

public class AdminHomeTest extends AdminLoginTest{
	
	AdminLoginPage objadlogin;
	AdminHomePage  objadhome;
	
	//VERIFY BOOKINGS
	@Test(priority=0)
    public void verifyBookings() throws IOException {
    //Create Login Page object
    objadlogin = new AdminLoginPage(driver);
    objadhome= new AdminHomePage(driver);
    
    //login to application
    String username = ExcelUtility.getCellData(0, 6);
    String password = ExcelUtility.getCellData(0, 7);
    objadlogin.setUserName(username);
    objadlogin.setPassword(password);
    objadlogin.clickLogin();
    
    String expectedUrl =AutomationConstants.ADMINHOMEPAGEURL;
    String actualUrl ="https://phptravels.net/api/admin";
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
    
     objadhome.clickBookings();
    
    String expectedBookingURL = AutomationConstants.ADMINMYBOOKINGSURL;
	String actualBookingURL = driver.getCurrentUrl();
	Assert.assertEquals(expectedBookingURL, actualBookingURL);
    
	System.out.println("Test Passed successfully");
    
	}
	
	
	//Admin Dashboard Booking Invoice
	
	@Test(priority=0)
    public void verifyBookingInvoice() throws IOException {
    //Create Login Page object
    objadlogin = new AdminLoginPage(driver);
    objadhome= new AdminHomePage(driver);
    
    //login to application
    String username = ExcelUtility.getCellData(0, 6);
    String password = ExcelUtility.getCellData(0, 7);
    objadlogin.setUserName(username);
    objadlogin.setPassword(password);
    objadlogin.clickLogin();
    
    
    String expectedUrl =AutomationConstants.ADMINHOMEPAGEURL;
    String actualUrl ="https://phptravels.net/api/admin";
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
    
   objadhome.clickBookings();
   objadhome.displayInvoice();
    
    
	}
	
	//Verify Website Link
	
	
	@Test(priority=0)
    public void verifyWebsiteLink() throws IOException {
    //Create Login Page object
    objadlogin = new AdminLoginPage(driver);
    objadhome= new AdminHomePage(driver);
    
    //login to application
    String username = ExcelUtility.getCellData(0, 6);
    String password = ExcelUtility.getCellData(0, 7);
    objadlogin.setUserName(username);
    objadlogin.setPassword(password);
    objadlogin.clickLogin();
    
    String expectedUrl =AutomationConstants.ADMINHOMEPAGEURL;
    String actualUrl ="https://phptravels.net/api/admin";
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
    
   objadhome.websiteLink();
    
    //Thread.sleep(5000);
	List<String> browserTabs = new ArrayList<String> (driver.getWindowHandles());
	//switch to new tab
	driver.switchTo().window(browserTabs .get(1));
	
	String expectedWebsiteURL = AutomationConstants.ADMINWEBSITEURL;
	String actualWebsiteURL = driver.getCurrentUrl();
	Assert.assertEquals(expectedWebsiteURL, actualWebsiteURL);
	
	}
}
