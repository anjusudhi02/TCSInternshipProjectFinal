package com.internshipproject.suppliertestcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.internshipproject.Agentpages.AgentLoginPage;
import com.internshipproject.constants.AutomationConstants;
import com.internshipproject.supplierpages.SupplierLoginPage;
import com.internshipproject.utilities.ExcelUtility;

public class SupplierLoginTest extends SupplierBaseClass{
	
	SupplierLoginPage objLogin;

	//CORRECT USERNAME AND PASSWORD
		@Test(priority=0)
	    public void verifyValidLogin() throws IOException {
	    //Create Login Page object
	    SupplierLoginPage objLogin = new SupplierLoginPage(driver);
	    //login to application
	    String username = ExcelUtility.getCellData(0, 2);
	    String password = ExcelUtility.getCellData(0, 3);
	    objLogin.setUserName(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();
	    String expectedUrl =AutomationConstants.SUPPLIERHOMEPAGEURL;
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
	   
		}
	
		@Test(priority=1)
	    public void verifyInValidUserLogin() throws IOException {
	    //Create Login Page object
	    SupplierLoginPage objLogin = new SupplierLoginPage(driver);
	    //login to application
	    String username = ExcelUtility.getCellData(1, 2);
	    String password = ExcelUtility.getCellData(1, 3);
	    objLogin.setUserName(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();
	    String expectedUrl ="https://phptravels.net/api/supplier";
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
	   
		}
		
		
		@Test(priority=2)
	    public void verifyInValidPasswordLogin() throws IOException {
	    //Create Login Page object
	    SupplierLoginPage objLogin = new SupplierLoginPage(driver);
	    //login to application
	    String username = ExcelUtility.getCellData(2, 2);
	    String password = ExcelUtility.getCellData(2, 3);
	    objLogin.setUserName(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();
	    String expectedUrl ="https://phptravels.net/api/supplier";
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
	   
		}
		
		@Test(priority=3)
	    public void verifyBlankLogin() throws IOException {
	    //Create Login Page object
	    SupplierLoginPage objLogin = new SupplierLoginPage(driver);
	    //login to application
	    //String username = ExcelUtility.getCellData(2, 2);
	    //String password = ExcelUtility.getCellData(2, 3);
	   // objLogin.setUserName(username);
	    //objLogin.setPassword(password);
	    objLogin.clickLogin();
	    String expectedUrl ="https://phptravels.net/api/supplier";
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
	   
		}
}
