package com.internshipproject.constants;

public class AutomationConstants{
	
	public static final String AGENTHOMEPAGEURL="https://phptravels.net/account/dashboard";
	public static final String AGENTBOOKINGURL="https://phptravels.net/account/bookings";
	public static final String AGENTMYPROFILEURL="https://phptravels.net/account/profile";
	public static final String AGENTADDFUNDURL="https://phptravels.net/account/add_funds";
	public static final String AGENTLOGOUT="https://phptravels.net/login";
	
	public static final String SUPPLIERHOMEPAGEURL="https://phptravels.net/api/supplier";
	public static final String SUPPLIERBOOKINGURL="https://phptravels.net/api/supplier/bookings";
	public static final String SUPPLIERTOURSURL="https://phptravels.net/api/supplier/tours";
	public static final String SUPPLIERREVENUE="Revenue Breakdown 2022";
	public static final String SUPPLIERSALES="Sales overview & summary";
	
	
	
	public static final String CUSTOMERHOMEPAGEURL="https://phptravels.net/account/dashboard";
	public static final String CUSTOMERMYBOOKINGSURL="https://phptravels.net/account/bookings";
	public static final String CUSTOMERADDFUNDSURL="https://phptravels.net/account/add_funds";
	public static final String CUSTOMERMYPROFILEURL="https://phptravels.net/account/profile";
	public static final String CUSTOMERLOGOUT="https://phptravels.net/login";
	public static final String CUSTOMERPAYPALURL="https://phptravels.net/payment";
	public static final String CUSTOMERVOUCHERURL="https://phptravels.net/account/bookings";
	
	
	public static final String ADMINHOMEPAGEURL="https://phptravels.net/api/admin";
	public static final String ADMINMYBOOKINGSURL="https://phptravels.net/api/admin/bookings";
	public static final String ADMINWEBSITEURL="https://phptravels.net/";
	
	
	
	
	
}