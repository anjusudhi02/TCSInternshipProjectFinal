package com.internshipproject.Admintestcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.internshipproject.adminpages.AdminLoginPage;
import com.internshipproject.constants.AutomationConstants;
import com.internshipproject.utilities.ExcelUtility;

public class AdminLoginTest extends AdminBaseClass {
	
AdminLoginPage objadlogin;
	//CORRECT USERNAME AND PASSWORD
	@Test(priority=0)
    public void verifyValidLogin() throws IOException {
    //Create Login Page object
    objadlogin = new AdminLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(0, 6);
    String password = ExcelUtility.getCellData(0, 7);
    objadlogin.setUserName(username);
    objadlogin.setPassword(password);
    objadlogin.clickLogin();
    String expectedUrl =AutomationConstants.ADMINHOMEPAGEURL;
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
   
	}
	
	// WRONG USERNAME AND CORRECT PASSWORD
	@Test(priority=0)
    public void verifyInvalidUserLogin() throws IOException {
    //Create Login Page object
    objadlogin = new AdminLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(1, 6);
    String password = ExcelUtility.getCellData(1, 7);
    objadlogin.setUserName(username);
    objadlogin.setPassword(password);
    objadlogin.clickLogin();
    String expectedUrl =AutomationConstants.ADMINHOMEPAGEURL;
    String actualUrl ="https://phptravels.net/api/admin";
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
   
	}

	//CORRECT  USERNAME AND WRONG PASSWORD
		@Test(priority=0)
	    public void verifyInvalidPasswordLogin() throws IOException {
	    //Create Login Page object
	    objadlogin = new AdminLoginPage(driver);
	    //login to application
	    String username = ExcelUtility.getCellData(2, 6);
	    String password = ExcelUtility.getCellData(2, 7);
	    objadlogin.setUserName(username);
	    objadlogin.setPassword(password);
	    objadlogin.clickLogin();
	    String expectedUrl =AutomationConstants.ADMINHOMEPAGEURL;
	    String actualUrl ="https://phptravels.net/api/admin";
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
	   
		}

		//BLANK
		@Test(priority=0)
	    public void verifyBlankLogin() throws IOException {
	    //Create Login Page object
	    objadlogin = new AdminLoginPage(driver);
	    //login to application
	    
	    objadlogin.clickLogin();
	    String expectedUrl =AutomationConstants.ADMINHOMEPAGEURL;
	    String actualUrl ="https://phptravels.net/api/admin";
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
	   
		}

	
		
}
