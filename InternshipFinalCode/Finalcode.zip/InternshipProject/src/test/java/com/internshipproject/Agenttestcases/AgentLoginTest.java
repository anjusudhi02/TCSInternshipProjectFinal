package com.internshipproject.Agenttestcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.internshipproject.Agentpages.AgentLoginPage;
import com.internshipproject.constants.AutomationConstants;
import com.internshipproject.utilities.ExcelUtility;

public class AgentLoginTest extends BaseClass {
AgentLoginPage objLogin;
	
	
	//CORRECT USERNAME AND PASSWORD
	@Test(priority=0)
    public void verifyValidLogin() throws IOException {
    //Create Login Page object
    objLogin = new AgentLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(0, 0);
    String password = ExcelUtility.getCellData(0, 1);
    objLogin.setUserName(username);
    objLogin.setPassword(password);
    objLogin.clickLogin();
    String expectedUrl =AutomationConstants.AGENTHOMEPAGEURL;
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
   
	}
	//WRONG USERNAME USERNAME AND PASSWORD
		@Test(priority=0)
	    public void verifyInValidUsernameLogin() throws IOException {
	    //Create Login Page object
	    objLogin = new AgentLoginPage(driver);
	    //login to application
	    String username = ExcelUtility.getCellData(1, 0);
	    String password = ExcelUtility.getCellData(1, 1);
	    objLogin.setUserName(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();
	    String expectedUrl ="https://phptravels.net/login/failed";
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
	   
		}
	//Correct username and Wrong Password
		
		@Test(priority=0)
	    public void verifyInValidPasswordLogin() throws IOException {
	    //Create Login Page object
	    objLogin = new AgentLoginPage(driver);
	    //login to application
	    String username = ExcelUtility.getCellData(2, 0);
	    String password = ExcelUtility.getCellData(2, 1);
	    objLogin.setUserName(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();
	    String expectedUrl ="https://phptravels.net/login/failed";
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
	   
		}

//Blank username and Password Login
		
		@Test(priority=0)
	    public void verifyBlankLogin() throws IOException {
	    //Create Login Page object
	    objLogin = new AgentLoginPage(driver);
	    //login to application
	    //String username = ExcelUtility.getCellData(2, 0);
	   // String password = ExcelUtility.getCellData(2, 1);
	    //objLogin.setUserName(username);
	    //objLogin.setPassword(password);
	    objLogin.clickLogin();
	    String expectedUrl ="https://phptravels.net/login/failed";
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
	   
		}

		
}
