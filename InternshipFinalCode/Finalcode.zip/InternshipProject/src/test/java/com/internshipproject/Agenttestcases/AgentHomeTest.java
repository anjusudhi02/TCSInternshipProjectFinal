package com.internshipproject.Agenttestcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.internshipproject.Agentpages.AgentHomePage;
import com.internshipproject.Agentpages.AgentLoginPage;
import com.internshipproject.constants.AutomationConstants;
import com.internshipproject.utilities.ExcelUtility;

public class AgentHomeTest extends AgentLoginTest
{
AgentHomePage objHome;
	
	
	//MY BOOKINGS VALIDATION
@Test(priority=1)
public void verifyMyProfile() throws IOException {
//Create Login Page object
objHome = new AgentHomePage(driver);
objLogin = new AgentLoginPage(driver);
//login to application
String username = ExcelUtility.getCellData(0, 0);
String password = ExcelUtility.getCellData(0, 1);
objLogin.setUserName(username);
objLogin.setPassword(password);
objLogin.clickLogin();
    
    objHome.clickBookings();
    String expectedUrl =AutomationConstants.AGENTBOOKINGURL;
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
   
	}
/*	
	//MY PROFILE VALIDATION
	@Test(priority=2)
    public void verifyMyProfile() throws IOException {
    //Create Login Page object
    objHome = new AgentHomePage(driver);
    objLogin = new AgentLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(0, 0);
    String password = ExcelUtility.getCellData(0, 1);
    objLogin.setUserName(username);
    objLogin.setPassword(password);
    objLogin.clickLogin();
    
    
    objHome.clickMyprofile();
   // String expectedUrl =AutomationConstants.AGENTMYPROFILEURL;
    
  //  String expectedUrl="https://phptravels.net/account/profile";
    String expectedUrl="https://phptravels.net/account/add_funds";
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
   
	}
	//ADD FUNDS VALIDATION
	
	@Test(priority=3)
    public void verifyAddFunds() throws IOException {
    //Create Login Page object
    objHome = new AgentHomePage(driver);
    objLogin = new AgentLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(0, 0);
    String password = ExcelUtility.getCellData(0, 1);
    objLogin.setUserName(username);
    objLogin.setPassword(password);
    objLogin.clickLogin();
    
    
    objHome.clickAddFund();
   // String expectedUrl =AutomationConstants.AGENTADDFUNDURL;
   // String expectedUrl="https://phptravels.net/account/add_funds";
    String expectedUrl="https://phptravels.net/account/profile";
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
	
	
}
	
	// VERIFY LOGOUT 
	
	@Test(priority=4)
    public void verifyLogout() throws IOException {
    //Create Login Page object
    objHome = new AgentHomePage(driver);
    objLogin = new AgentLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(0, 0);
    String password = ExcelUtility.getCellData(0, 1);
    objLogin.setUserName(username);
    objLogin.setPassword(password);
    objLogin.clickLogin();
    
    
    objHome.clickLogout();
    String expectedUrl =AutomationConstants.AGENTLOGOUT;
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
	
	}
	
	
	// VERIFY Flights
	
	@Test(priority=5)
    public void verifyFlights() throws IOException {
    //Create Login Page object
    objHome = new AgentHomePage(driver);
    objLogin = new AgentLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(0, 0);
    String password = ExcelUtility.getCellData(0, 1);
    objLogin.setUserName(username);
    objLogin.setPassword(password);
    objLogin.clickLogin();
    
    
    objHome.clickFlight();
    String expectedUrl ="https://phptravels.net/flights";
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
	
	}
	
	

	
	// VERIFY Visa
	
	@Test(priority=6)
    public void verifyVisa() throws IOException {
    //Create Login Page object
    objHome = new AgentHomePage(driver);
    objLogin = new AgentLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(0, 0);
    String password = ExcelUtility.getCellData(0, 1);
    objLogin.setUserName(username);
    objLogin.setPassword(password);
    objLogin.clickLogin();
    
    
    objHome.clickVisa();
    String expectedUrl ="https://phptravels.net/visa";
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
	
	}
	
	
	
	// VERIFY Blog
	
		@Test(priority=7)
	    public void verifyBlog() throws IOException {
	    //Create Login Page object
	    objHome = new AgentHomePage(driver);
	    objLogin = new AgentLoginPage(driver);
	    //login to application
	    String username = ExcelUtility.getCellData(0, 0);
	    String password = ExcelUtility.getCellData(0, 1);
	    objLogin.setUserName(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();
	    
	    
	    objHome.clickBlog();
	    String expectedUrl ="https://phptravels.net/blog";
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
		
		}
		
		
	
		
		// VERIFY offers
		
		@Test(priority=8)
	    public void verifyOffers() throws IOException {
	    //Create Login Page object
	    objHome = new AgentHomePage(driver);
	    objLogin = new AgentLoginPage(driver);
	    //login to application
	    String username = ExcelUtility.getCellData(0, 0);
	    String password = ExcelUtility.getCellData(0, 1);
	    objLogin.setUserName(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();
	    
	    
	    objHome.clickOffers();
	    String expectedUrl ="https://phptravels.net/offers";
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
		
		}
		
		
	// Validation of Hotels and  Hotels Search
	@Test(priority=9)
	    public void verifyHotel() throws IOException {
	    //Create Login Page object
	    objHome = new AgentHomePage(driver);
	    objLogin = new AgentLoginPage(driver);
	    //login to application
	    String username = ExcelUtility.getCellData(0, 0);
	    String password = ExcelUtility.getCellData(0, 1);
	    objLogin.setUserName(username);
	    objLogin.setPassword(password);
	    objLogin.clickLogin();
	    
	    
	    objHome.clickHotel();
	    
	    String expectedUrl ="https://phptravels.net/hotels/en/usd/delhi/30-10-2022/31-10-2022/1/2/0/US";
	    String actualUrl =driver.getCurrentUrl();
	    Assert.assertEquals(expectedUrl,actualUrl);
	    System.out.println("Test Passed successfully");
	    
		
		}
	
	//Validation of Currency
	
	@Test(priority=9)
    public void verifyCurrency() throws IOException {
    //Create Login Page object
    objHome = new AgentHomePage(driver);
    objLogin = new AgentLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(0, 0);
    String password = ExcelUtility.getCellData(0, 1);
    objLogin.setUserName(username);
    objLogin.setPassword(password);
    objLogin.clickLogin();
    
    objHome.Currencybtn();
    
    
    
    
	}
	
	*/
	
	}
