package com.internshipproject.customertestcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.internshipproject.Agentpages.AgentLoginPage;
import com.internshipproject.constants.AutomationConstants;
import com.internshipproject.customerpages.CustomerLoginPage;
import com.internshipproject.utilities.ExcelUtility;

public class CustomerLoginTest extends CustomerBaseClass {
	
	
CustomerLoginPage objLogin;
	
	
	//CORRECT USERNAME AND PASSWORD
	@Test(priority=0)
    public void verifyValidLogin() throws IOException {
    //Create Login Page object
    objLogin = new CustomerLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(0, 4);
    String password = ExcelUtility.getCellData(0, 5);
    objLogin.setUsername(username);
    objLogin.setPassword(password);
    objLogin.clickLogin();
    String expectedUrl =AutomationConstants.CUSTOMERHOMEPAGEURL;
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
   
	}
	
	@Test(priority=1)
    public void verifyInValidUserLogin() throws IOException {
    //Create Login Page object
    objLogin = new CustomerLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(1, 4);
    String password = ExcelUtility.getCellData(1, 5);
    objLogin.setUsername(username);
    objLogin.setPassword(password);
    objLogin.clickLogin();
    String expectedUrl ="https://phptravels.net/login/failed";
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
    
	}

	@Test(priority=1)
    public void verifyInValidPasswordLogin() throws IOException {
    //Create Login Page object
    objLogin = new CustomerLoginPage(driver);
    //login to application
    String username = ExcelUtility.getCellData(1, 4);
    String password = ExcelUtility.getCellData(1, 5);
    objLogin.setUsername(username);
    objLogin.setPassword(password);
    objLogin.clickLogin();
    String expectedUrl ="https://phptravels.net/login/failed";
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
    
	}

	@Test(priority=1)
    public void verifyBlankLogin() throws IOException {
    //Create Login Page object
    objLogin = new CustomerLoginPage(driver);
    //login to application
   // String username = ExcelUtility.getCellData(1, 4);
   // String password = ExcelUtility.getCellData(1, 5);
   // objLogin.setUsername(username);
   // objLogin.setPassword(password);
    objLogin.clickLogin();
    String expectedUrl ="https://phptravels.net/login";
    String actualUrl =driver.getCurrentUrl();
    Assert.assertEquals(expectedUrl,actualUrl);
    System.out.println("Test Passed successfully");
    
    
    
   
	}

}
