package com.internshipproject.Agentpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AgentLoginPage {
WebDriver driver;
	
	@FindBy(xpath="/html/body/div[4]/div/div[2]/div[2]/div/form/div[1]/div/input")
	private  WebElement username;
	
	@FindBy(xpath="/html/body/div[4]/div/div[2]/div[2]/div/form/div[2]/div[1]/input")
	private  WebElement password;
	
	@FindBy(xpath="/html/body/div[4]/div/div[2]/div[2]/div/form/div[3]/button/span[1]")
	private  WebElement loginbtn;
	
	/*@FindBy(xpath="//*[@id=\"login_button_container\"]/div/form/div[3]/h3")
    private WebElement errorMessage;
    
    @FindBy(xpath="//*[@id=\"login_button_container\"]/div/form/div[3]/h3")
    private WebElement blankPasswordMessage;
    
    @FindBy(xpath="//*[@id=\"login_button_container\"]/div/form/div[3]/h3")
    private WebElement blankUserMessage;
    
	
	*/
	
	
	public AgentLoginPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	
	public  void setUserName(String strUserName)
	{
		username.sendKeys(strUserName);
		
	}
	public  void setPassword(String strPassword)
	{
		password.sendKeys(strPassword);
		
	}
	/*
	public String getInvalidMessage(){
    	return errorMessage.getText();
    }
    /*
    public String getBlankPasswordMessage(){
    	return blankPasswordMessage.getText();
    }
    
    public String getBlankUserMessage(){
    	return blankUserMessage.getText();
    }*/
	
	public  void clickLogin()
	{
		loginbtn.submit();
	}
	
	

}
