package com.internshipproject.supplierpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SupplierHomePage {
	
	WebDriver driver;
	//Actions action;
		
		/*@FindBy(xpath="")
		private  WebElement Flight;
		
		@FindBy(xpath="")
		private  WebElement Visa;*/
	
		@FindBy(xpath="/html/body/nav/div/div/ul/li[2]/a")
		private  WebElement Bookings;
		
		@FindBy(xpath="/html/body/div[2]/div[1]/nav/div/div/a[6]")
		private  WebElement Tours;
		
		
		@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[1]/div[1]/div")
		private  WebElement Salesoverview;
	
	
		@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[3]/div[1]/div/div[1]/div/div/h2")
		private  WebElement RevenueBreakdown;
		
		public SupplierHomePage(WebDriver driver)
		{
			this.driver=driver;
			PageFactory.initElements(driver, this);
			
		}

		public  void clickBookings()
		{
			Bookings.click();
		}


		public  void clickTours()
		{
			Tours.click();
		}

	public  void clickRevenue()
		{
			String revenueText =RevenueBreakdown.getText();
		}
		
		
		
		
		
		
		
}
