package com.internshipproject.Agentpages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AgentHomePage {
	
WebDriver driver;
//Actions action;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[4]/a")
	private  WebElement MyProfile;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[3]/a")
	private  WebElement Addfunds;
	
	@FindBy(xpath="//*[@id=\"fadein\"]/div[4]/div/div[3]/ul/li[2]/a")
	private  WebElement Bookings;
	
	@FindBy(xpath="/html/body/div[4]/div/div[3]/ul/li[5]/a")
	private  WebElement logout;
	
	@FindBy(xpath="/html/body/header/div/div/div/div/div/div[2]/div/div[1]/nav/ul/li[2]/a")
	private  WebElement Flights;
	
	@FindBy(xpath="/html/body/header/div/div/div/div/div/div[2]/div/div[1]/nav/ul/li[3]/a")
	private  WebElement Tours;
	
	
	@FindBy(xpath="/html/body/header/div/div/div/div/div/div[2]/div/div[1]/nav/ul/li[5]/a")
	private  WebElement Visa;
	
	
	
	@FindBy(xpath="/html/body/header/div/div/div/div/div/div[2]/div/div[1]/nav/ul/li[6]/a")
	private  WebElement Blog ;

	@FindBy(xpath="/html/body/header/div/div/div/div/div/div[2]/div/div[1]/nav/ul/li[7]/a")
	private  WebElement Offers;
	

	@FindBy(xpath="/html/body/header/div/div/div/div/div/div[2]/div/div[1]/nav/ul/li[1]/a")
	private  WebElement Hotel;
	
	@FindBy(id="select2-hotels_city-container")
	private  WebElement City;
	
	@FindBy(xpath="/html/body/section[1]/section/div/div/form/div")
	private WebElement Cityname;
	
	@FindBy(id="submit")
	private  WebElement Searchbtn;
	
	@FindBy(id="currency")
	private  WebElement Currency;
	
	//List<WebElement> allOptions = driver.findElements(By.xpath("/html/body/header/div/div/div/div/div/div[2]/div/div[2]/div[2]/div/button"));
    
	@FindBy(xpath="/html/body/header/div/div/div/div/div/div[2]/div/div[2]/div[2]/div/ul/li[7]/a")
	private  WebElement Inr;


public AgentHomePage(WebDriver driver)
{
	this.driver=driver;
	PageFactory.initElements(driver, this);
	
}

public  void clickBookings()
{
	Bookings.click();
}


public  void clickAddFund()
{
	MyProfile.click();
}


public  void clickMyprofile()
{
	Addfunds.click();
}

public  void clickLogout()
{
	logout.click();
}


public  void clickFlight()
{
	Flights.click();
}


public  void clickVisa()
{
	Visa.click();
}

public  void clickBlog()
{
	Blog.click();
}
public  void clickTour()
{
	Tours.click();
}
public  void clickOffers()
{
	Offers.click();
}

public  void clickHotel()
{
	Hotel.click();
	City.sendKeys("Delhi");
	Cityname.click();
	Searchbtn.submit();
	
}

public void Currencybtn()
{
	Currency.click();
	Inr.click();

		}
		
		
	}
	
	


