package com.internshipproject.customerpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerLoginPage {
	WebDriver driver;
	
	@FindBy(name = "email")
	private WebElement username;

	@FindBy(name = "password")
	private WebElement password;

	
	@FindBy(xpath = "/html/body/div[4]/div/div[2]/div[2]/div/form/div[3]/button")
	private WebElement Login;

	public CustomerLoginPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	
	

	
	public void setUsername(String strUsername) {
	username.sendKeys(strUsername);
	}


	public void setPassword(String strPassword) {
	password.sendKeys(strPassword);
	}


	public void clickLogin() {
	Login.click();
	}

	
	
}
