package com.internshipproject.utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelUtility {
	private static XSSFWorkbook excelWbook;
	private static XSSFSheet excelWsheet;
	
		public static String getCellData(int RowNum, int ColNum) throws IOException{
			FileInputStream ExcelFile=new FileInputStream(System.getProperty("user.dir")+ "/src/main/resources"+"/TestData.xlsx");
			excelWbook=new XSSFWorkbook(ExcelFile);
			excelWsheet=excelWbook.getSheetAt(0);
			return excelWsheet.getRow(RowNum).getCell(ColNum).getStringCellValue();
			
					
					
				
			
					
		
	}

	

}
