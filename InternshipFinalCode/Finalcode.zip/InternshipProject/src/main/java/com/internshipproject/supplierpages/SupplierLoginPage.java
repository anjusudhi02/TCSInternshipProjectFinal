package com.internshipproject.supplierpages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SupplierLoginPage {
	
	WebDriver driver;
	

	@FindBy(xpath="/html/body/div/div[1]/main/div/div/div/div[1]/div/form/div[1]/label/input")
	private  WebElement username;
	
	@FindBy(xpath="/html/body/div/div[1]/main/div/div/div/div[1]/div/form/div[2]/label/input")
	private  WebElement password;
	
	@FindBy(xpath="/html/body/div/div[1]/main/div/div/div/div[1]/div/form/div[4]/button/span[1]")
	private  WebElement loginbtn;
		
	public SupplierLoginPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	
	public  void setUserName(String strUserName)
	{
		username.sendKeys(strUserName);
		
	}
	public  void setPassword(String strPassword)
	{
		password.sendKeys(strPassword);
		
	}	


	public  void clickLogin()
	{
		loginbtn.submit();
	}
	
	
}
